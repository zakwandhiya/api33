<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use Restserver\Libraries\REST_Controller;
require(APPPATH . 'libraries/REST_Controller.php');

class MasterController extends REST_Controller {
    function __construct($config = 'rest') {
        parent::__construct($config);
        // parent::__construct();
        $this->load->model('AuthModel');
        $this->load->model('MasterModel');
        $this->data["title"] = "";
        date_default_timezone_set("Asia/Jakarta"); 
        $this->dateToday = date("Y-m-d H:i:s");
        $this->timeToday = date("h:i:s");
    }

    function dataLakonAll_get(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $result = $this->MasterModel->getLakonAll()->result();
            $this->response(array('status' => 'success','msg' => 'Show list data', 'data' => $result));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function dataUserAll_get(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $result = $this->MasterModel->getUserAll()->result();
            $this->response(array('status' => 'success','msg' => 'Show list data', 'data' => $result));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function dataKategori_get(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $result = $this->MasterModel->getKategori()->result();
            $this->response(array('status' => 'success','msg' => 'Show list data', 'data' => $result));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function tampilkanIklan_get(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $result = $this->MasterModel->getIklan()->result();
            $this->response(array('status' => 'success','msg' => 'Show list data', 'data' => $result));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function hasilPencarian_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $cari = $this->input->post('cari');
            $result = $this->MasterModel->getPencarian($cari)->result();
            $this->response(array('status' => 'success','msg' => 'Search is correct!', 'data' => $result));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function infoAkun_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $result = $this->MasterModel->getInfoAkun($id);
            $check = $result->num_rows();
            if($check > 0){
                $result = $result->row();
                $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $result));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Get information is Incorrect!'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function updateInfoAkun_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $latitude = $this->input->post('latitude');
            $longitude = $this->input->post('longitude');
            $deskripsi = $this->input->post('deskripsi');
            $foto_url = $this->input->post('foto_url');
            $result = $this->MasterModel->getInfoAkun($id);
            $check = $result->num_rows();
            if($check > 0){
                $data = array(
                    'nama' => $nama,
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'deskripsi' => $deskripsi, 
                    'foto_url' => $foto_url,
                    'tanggal_diubah' => $this->dateToday
                );
                $id = $result->row('id');
                $update = $this->AuthModel->userUpdate($data, $id);
                if($update>0){
                    $this->response(array('status' => 'success','msg' => 'Update is success!'));
                }else{
                    $this->response(array('status' => 'failed','msg' => 'Update is failed! Try to update different data value'));
                }
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }
    
    function infoHarga_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $result = $this->MasterModel->getInfoHargaAll($id);
            $check = $result->num_rows();
            if($check > 0){
                $result = $result->result();
                $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $result));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Get information is Incorrect!'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function updateInfoHarga_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id_layanan = $this->input->post('id_layanan');
            $nama_layanan = $this->input->post('nama_layanan');
            $deskripsi = $this->input->post('deskripsi');
            $harga = $this->input->post('harga');
            $status_promo = $this->input->post('status_promo');
            $data = array(
                'nama_layanan' => $nama_layanan,
                'deskripsi' => $deskripsi,
                'harga' => $harga,
                'status_promo' => $status_promo
            );
            $update = $this->MasterModel->updateInfoHarga($data, $id_layanan);
            if($update > 0){
                $this->response(array('status' => 'success','msg' => 'Update is success!'));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Update is failed! Try to update different data value'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function deleteInfoHarga_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id_layanan = $this->input->post('id_layanan');
            $delete = $this->MasterModel->deleteInfoHarga($id_layanan);
            if($delete > 0){
                $this->response(array('status' => 'success','msg' => 'Delete is success!', 'affected rows' => $delete));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Delete is failed! Try to update different data value'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function infoGaleri_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $result = $this->MasterModel->getInfoGaleri($id);
            $check = $result->num_rows();
            if($check > 0){
                $result = $result->result();
                $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $result));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Get information is Incorrect!'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function masukkanHargaLayanan_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $user = $this->AuthModel->userDataById($id);
            $check = $user->num_rows();
            if($check > 0){
                $id_pelakon = $user->row('id');
                $nama_layanan = $this->input->post('nama_layanan');
                $deskripsi = $this->input->post('deskripsi');
                $harga = $this->input->post('harga');
                $status_promo = $this->input->post('status_promo');
                $data = array(
                    'id_pelakon' => $id_pelakon,
                    'nama_layanan' => $nama_layanan,
                    'deskripsi' => $deskripsi,
                    'harga' => $harga,
                    'status_promo' => $status_promo
                );
                $insert = $this->MasterModel->insertInfoHarga($data);
                if($insert > 0){
                    $this->response(array('status' => 'success','msg' => 'Insert is success!','affected' => $insert));
                }
                else{
                    $this->response(array('status' => 'failed','msg' => 'Insert is failed!'));
                }
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Get information is Incorrect!'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function updateInfoGaleri_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id_foto = $this->input->post('id_foto');
            //$id_pelakon = $this->input->post('id_pelakon');
            $foto_url = $this->input->post('foto_url');
            $data = array(
                'foto_url' => $foto_url
            );
            $update = $this->MasterModel->updateInfoGaleri($data, $id_foto);
            if($update > 0){
                $this->response(array('status' => 'success','msg' => 'Update is success!'));
            }
            else{
                $this->response(array('status' => 'failed','msg' => 'Update is failed! Try to update different data value'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function masukkanTransaksi_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            //data transaksi
            $id_pelakon = $this->input->post('id_pelakon');
            $id_member = $this->input->post('id_member');
            $jam = $this->input->post('jam');
            $tanggal = $this->input->post('tanggal');
            $keterangan = $this->input->post('keterangan');
            $alamat = $this->input->post('alamat');
            //masukkan ke database
            $data = array(
                'id_pelakon' => $id_pelakon,
                'id_member' => $id_member,
                'jam' => $jam,
                'tanggal' => $tanggal,
                'tipe_pembayaran' => 'cash',
                'keterangan' => $keterangan,
                'alamat' => $alamat,
                'status_kesepakatan_tanggal' => 'pending',
                'status_pembayaran' => 'pending',
                'tanggal_dibuat' => $this->dateToday,
                'tanggal_diubah' => $this->dateToday,
                'ongkos' => 2500
            );
            $insert = $this->MasterModel->insertTransaksi($data);
            $id_pemesanan = $insert;
            if(isset($id_pemesanan) > 0){
                //data transaksi item yang masuk
                $id_layanan = $this->input->post('id_layanan'); //tipe string. ex: 1,2,3
                $jumlah_layanan = $this->input->post('jumlah_layanan'); //tipe string, ex: 2,4,6
                $kuantitas = $this->input->post('kuantitas');
                $array_layanan = explode(',', $id_layanan); //pemecahan string menjadi array 2 dimensi
                $array_jumlah_layanan = explode(',', $jumlah_layanan); //pemecahan string menjadi array 2 dimensi
                $array_kuantitas = explode(',', $kuantitas);
                //untuk memasukkan item ke db, ambil id dari transaksi terlebih dahulu
                //$idTransaksi = insert traksai ke model -> ini isinya id transaksi yg terakhir kali di insertin = 10
                for($i = 0; $i < count($array_layanan); $i++){
                    $layanan = $this->MasterModel->getLayananById($array_layanan[$i]);
                    $data2 = array(
                        'id_pemesanan' => $id_pemesanan,
                        'id_layanan' => $array_layanan[$i],
                        'nama_layanan' => $layanan->row('nama_layanan'),
                        'harga_satuan' => $layanan->row('harga'), //masukkan dengan id, bukan inputan user
                        'kuantitas' => $array_kuantitas[$i],
                        'harga_total' => $layanan->row('harga')*$array_kuantitas[$i]
                    );
                    $insert = $this->MasterModel->insertTransaksiItem($data2);
                } 
               $this->response(array('status' => 'success','msg' => 'Insert Item is correct!'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function daftarTransaksi_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $role = $this->input->post('role');
            if($role == 'member'){
                $result = $this->MasterModel->getTransaksiMember($id)->result();
                
                $arrayData = array();
                $i = 0;
                foreach($result as $row){
                    $arrayData[$i]['id_pemesanan']= $row->id_pemesanan;
                    $arrayData[$i]['id_pelakon'] = $row->id_pelakon;
                    $arrayData[$i]['id_member'] = $row->id_member;
                    $arrayData[$i]['nama_pelakon'] = $this->MasterModel->getTransaksiUser($row->id_pelakon)->row('nama');
                    $arrayData[$i]['nama_member'] = $this->MasterModel->getTransaksiUser($row->id_member)->row('nama');
                    $arrayData[$i]['jam'] = $row->jam;
                    $arrayData[$i]['tanggal'] = $row->tanggal;
                    $arrayData[$i]['ongkos'] = $row->ongkos;
                    $arrayData[$i]['keterangan'] = $row->keterangan;
                    $arrayData[$i]['alamat'] = $row->alamat;
                    $arrayData[$i]['tipe_pembayaran'] = $row->tipe_pembayaran;
                    $arrayData[$i]['status_kesepakatan_tanggal'] = $row->status_kesepakatan_tanggal;
                    $arrayData[$i]['status_pembayaran'] = $row->status_pembayaran;
                    $id = $row->id_pemesanan;
                    $resultItem = $this->MasterModel->getTransaksiItem($id)->result();
                    $j = 0;
                    $arrayData[$i]['transaksi_item'] = array();
                    $total_harga = 0;
                    foreach($resultItem as $r){
                        $arrayData[$i]['transaksi_item'][$j]['id_item']= $r->id_item;
                        $arrayData[$i]['transaksi_item'][$j]['id_layanan']= $r->id_layanan;
                        $arrayData[$i]['transaksi_item'][$j]['nama_layanan']= $r->nama_layanan;
                        $arrayData[$i]['transaksi_item'][$j]['harga_satuan']= $r->harga_satuan;
                        $arrayData[$i]['transaksi_item'][$j]['kuantitas']= $r->kuantitas;
                        $total_harga = $total_harga + ($r->kuantitas * $r->harga_satuan);
                        $j++;
                    };
                    $arrayData[$i]['total_harga'] = (string)$total_harga;
                    $i++;
                }
                $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $arrayData));
            }
            else if($role == 'lakon'){
                $result = $this->MasterModel->getTransaksiLakon($id)->result();
                $nama = $this->MasterModel->getTransaksiUser($id, $role)->row('nama');
                $arrayData = array();
                $i = 0;
                foreach($result as $row){
                    $arrayData[$i]['id_pemesanan']= $row->id_pemesanan;
                    $arrayData[$i]['id_pelakon'] = $row->id_pelakon;
                    $arrayData[$i]['id_member'] = $row->id_member;
                    $arrayData[$i]['nama_pelakon'] = $this->MasterModel->getTransaksiUser($row->id_pelakon)->row('nama');
                    $arrayData[$i]['nama_member'] = $this->MasterModel->getTransaksiUser($row->id_member)->row('nama');
                    $arrayData[$i]['jam'] = $row->jam;
                    $arrayData[$i]['tanggal'] = $row->tanggal;
                    $arrayData[$i]['ongkos'] = $row->ongkos;
                    $arrayData[$i]['keterangan'] = $row->keterangan;
                    $arrayData[$i]['alamat'] = $row->alamat;
                    $arrayData[$i]['tipe_pembayaran'] = $row->tipe_pembayaran;
                    $arrayData[$i]['status_kesepakatan_tanggal'] = $row->status_kesepakatan_tanggal;
                    $arrayData[$i]['status_pembayaran'] = $row->status_pembayaran;
                    $id = $row->id_pemesanan;
                    $resultItem = $this->MasterModel->getTransaksiItem($id)->result();
                    $j = 0;
                    $arrayData[$i]['transaksi_item'] = array();
                    $total_harga = 0;
                    foreach($resultItem as $r){
                        $arrayData[$i]['transaksi_item'][$j]['id_item']= $r->id_item;
                        $arrayData[$i]['transaksi_item'][$j]['id_layanan']= $r->id_layanan;
                        $arrayData[$i]['transaksi_item'][$j]['nama_layanan']= $r->nama_layanan;
                        $arrayData[$i]['transaksi_item'][$j]['harga_satuan']= $r->harga_satuan;
                        $arrayData[$i]['transaksi_item'][$j]['kuantitas']= $r->kuantitas;
                        $total_harga = $total_harga + ($r->kuantitas * $r->harga_satuan);
                        $j++;
                    };
                    $arrayData[$i]['total_harga'] = (string)$total_harga;
                    $i++;
                }
                $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $arrayData));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function detailTransaksi_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id = $this->input->post('id');
            $result = $this->MasterModel->getTransaksiDetail($id)->result();
            $arrayData = array();
            $i = 0;
            foreach($result as $row){
                $arrayData[$i]['id_pemesanan']= $row->id_pemesanan;
                $arrayData[$i]['id_pelakon'] = $row->id_pelakon;
                $arrayData[$i]['id_member'] = $row->id_member;
                $arrayData[$i]['total'] = $row->total;
                $arrayData[$i]['jam'] = $row->jam;
                $arrayData[$i]['tanggal'] = $row->tanggal;
                $arrayData[$i]['tipe_pembayaran'] = $row->tipe_pembayaran;
                $arrayData[$i]['status_kesepakatan_tanggal'] = $row->status_kesepakatan_tanggal;
                $arrayData[$i]['status_pembayaran'] = $row->status_pembayaran;
                $id = $row->id_pemesanan;
                $resultItem = $this->MasterModel->getTransaksiItem($id)->result();
                $j = 0;
                $arrayData[$i]['transaksi_item'] = array();
                foreach($resultItem as $r){
                    $arrayData[$i]['transaksi_item'][$j]['id_item']= $r->id_item;
                    $arrayData[$i]['transaksi_item'][$j]['id_layanan']= $r->id_layanan;
                    $arrayData[$i]['transaksi_item'][$j]['nama_layanan']= $r->nama_layanan;
                    $arrayData[$i]['transaksi_item'][$j]['harga_satuan']= $r->harga_satuan;
                    $arrayData[$i]['transaksi_item'][$j]['kuantitas']= $r->kuantitas;
                    $j++;
                }
                $i++;
            }
            $this->response(array('status' => 'success','msg' => 'Get information is correct!', 'data' => $arrayData));
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function masukkanNego_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id_transaksi = $this->input->post('id_transaksi');
            $jam = $this->input->post('jam');
            $tanggal = $this->input->post('tanggal');
            $alamat = $this->input->post('alamat');
            $keterangan = $this->input->post('keterangan');
            $data = array(
                'id_transaksi' => $id_transaksi,
                'jam' => $jam,
                'tanggal' => $tanggal,
                'alamat' => $alamat,
                'keterangan' => $keterangan,
                'tanggal_dibuat' => $this->dateToday,
                'tanggal_diubah' => $this->dateToday
            );
            $insert = $this->MasterModel->insertNego($data);
            if(isset($insert)){
                $this->response(array('status' => 'success','msg' => 'Insert Item is success!'));
            }
            else{
                $this->response(array('status' => 'success','msg' => 'Failed to Insert! please try again'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }

    function detailNego_post(){
        $header = $this->input->request_headers();
        $key = $header['key'];
        $check = $this->AuthModel->getKey($key)->num_rows();
        if($check > 0){
            $id_transaksi = $this->input->post('id_transaksi');
            $result = $this->MasterModel->getNego($id_transaksi);
            if($result->num_rows() > 0){
                $this->response(array('status' => 'success','msg' => 'Get Information is success!', 'data' => $result->result()));
            }
            else{
                $this->response(array('status' => 'success','msg' => 'Failed to get Informastion! please try again'));
            }
        }
        else{
            $this->response(array('status' => 'failed','msg' => 'Header is incorrect!'));
        }
    }
}