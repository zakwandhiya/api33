<?php
    $config['telegram_bot_id'] = 'bot user id';
    $config['telegram_bot_key'] = 'API KEY';
    $config['telegram_bot_name'] = 'Karya Studio Telegram Bot';
    $config['creator'] = 'your user id';
?>
